<?php
namespace wanzhen;
use GuzzleHttp\Client as HttpClient;
class CoupangClient
{
    protected $baseUrl;
    protected $httpClient;

    public function __construct($baseUrl)
    {
        $this->baseUrl = $baseUrl;
        $this->httpClient = new HttpClient([
            'base_uri' => $baseUrl,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);
    }
    public function getUsers()
    {
        $response = $this->httpClient->get('/api/users');
        return json_decode($response->getBody(), true);
    }
}